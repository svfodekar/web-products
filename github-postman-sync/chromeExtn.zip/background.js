chrome.action.onClicked.addListener(() => {
    const extensionId = chrome.runtime.id;
    console.log("Extension ID:", chrome.runtime.id);
    const websiteUrl = `https://codytools.com/github-postman-sync/?extensionId=${extensionId}`; // Append extension ID
    chrome.tabs.create({ url: websiteUrl });
});


chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    console.log("📩 Received message in background.js:", message);

    if (message.action === "getToken") {
        console.log("🔑 Fetching token...");
       // const token = localStorage.getItem("postmanToken") || "No Token Found";
        sendResponse({ token : 'sdcdscsdc' });
    } else {
        console.warn("⚠️ Unknown action received:", message.action);
    }

   // return true; // Keeps the message channel open for async response
});
